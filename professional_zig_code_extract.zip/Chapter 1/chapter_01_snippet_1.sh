brew install zig
