zigmod init
Use zigmod fetch to retrieve the libraries and their dependencies.
