zigmod fetch
