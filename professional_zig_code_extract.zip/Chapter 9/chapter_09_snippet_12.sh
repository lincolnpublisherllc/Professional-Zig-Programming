zig build --release-fast
