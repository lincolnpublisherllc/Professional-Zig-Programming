zig build -Doptimize=Debug
